const crypto = require('crypto') ;

const aesCreateKey = () => {
    // Generate a secret key for encryption and decryption
    const key = crypto.randomBytes(32); // 32 bytes = 256 bits
    const iv = crypto.randomBytes(16); // 16 bytes = 128 bits

    const result = key.toString('base64') + ':' + iv.toString('base64');
    console.log(result)
    return result;
};
aesCreateKey();